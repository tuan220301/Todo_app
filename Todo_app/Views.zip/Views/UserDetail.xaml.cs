﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading.Tasks;
using Todo_app.Models;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Todo_app.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class UserDetail : ContentPage
	{
		
		
		public UserDetail ()
		{
			InitializeComponent ();
            var isEmpty = (App.UserController.ReadUser()).ToArray();
            Console.WriteLine("Length of list user" + isEmpty.Length);
            if (isEmpty.Length == 0)
            {
                Navigation.PushAsync(new AddUser());
            }
        }
        
        protected override void OnAppearing()
		{
			base.OnAppearing();
            showUser.ItemsSource = (App.UserController.ReadUser()).OrderByDescending(i => (i.UserId)).ToList();
        }
        private void EditUser(object sender, EventArgs e)
        {

            User user = (User)showUser.SelectedItem;
            Navigation.PushAsync(new AddUser(user));
        }
        private async void Delete(object sender, EventArgs e)
        {
            var swipeItem = sender as SwipeItem;
            var user = swipeItem.CommandParameter as User;

            bool answer = await DisplayAlert("Thông báo", $"Bạn có muốn xóa {user.UserName} không?", "CÓ", "KHÔNG");
            if (answer)
            {
                App.UserController.DeleteUser(user);
                showUser.ItemsSource = (App.UserController.ReadUser()).OrderByDescending(i => (i.UserId)).ToList();
            }
        }

    }
}